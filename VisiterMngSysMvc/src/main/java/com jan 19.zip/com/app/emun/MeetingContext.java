package com.app.emun;

public enum MeetingContext {
	BUSINESS, INTERVIEW, CASUAL, OTHERS
}
