package com.app.emun;


public enum MeetingStatus {

	PENDING, APPROVED, INPROCESS, RESCHEDULED, COMPLETED, CANCELLED
	
}
