package com.app.constants;

public enum VisitorStatus {
	
	    PENDING_APPROVAL,
	    APPROVED,
	    CHECKED_IN,
	    CHECKED_OUT,

}
