package com.app.constants;

public class VmsConstants {
	
	public static final String SOMETHING_WENT_WRONG = "something went wrong ";

	public static final String INVALID_DATA = "Invalid Data ";
	
	public static final String UNAUTHORIZED_ACCESS = "Unauthrized access";

	public static final String STORE_LOCATION= "/home/rapidsoft/Desktop/pdf_download";
	
	public static final String OK= "successful";

}
